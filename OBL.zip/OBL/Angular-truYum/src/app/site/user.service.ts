import { Injectable } from '@angular/core';
import { IUser } from './IUser.Module';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }
  users:IUser[]=[
    {id:1,username:"Admin",password:"password"},
    {id:2,username:"John",password:"pass"}]

    addUser(user:IUser):void
    {
      this.users.push(user);
    }
    getUser(name:string):IUser
    {
      return this.users.find(u=>u.username==name);
    }
}
