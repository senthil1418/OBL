import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuardService } from '../../auth-guard.service';
import { AuthService } from '../../auth.service';
import { UserService } from '../user.service';
import { IUser } from '../IUser.Module';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:IUser;
  constructor(private userService:UserService,private _router: Router,private _authService:AuthService) { }
msg:string;
  ngOnInit() {
  }

  onSubmit(username:string,password:string){
    this.user=this.userService.getUser(username);
    if(username=="admin" && password=="password")
    {
    this._authService.login();
    this._router.navigate(['FoodItemsAdmin']);
    }
    else if(this.user!=null && this.user.username==username && this.user.password==password)
      {
      this._authService.login();
      this._router.navigate(['FoodItemsCustomer']);
      }
    
    else
    {
      this.msg="Invalid Username and Password"
    }
    
  }

  // login (username:string,password:string){
  //   if(username=="admin" && password=="password")
  //   {
  //     this._router.navigate(['FoodItemsAdmin']);
  //   }
  //   else if(username=="customer" && password=="pass")
  //   {
  //     this._router.navigate(['FoodItemsCustomer']);
  //   }
  //   else
  //   {
  //     this.msg="Invalid User Name and Password"
  //     this._router.navigate(['Login'])
  //   }
  // }
}
