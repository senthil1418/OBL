import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FoodMenuComponent } from '../food/menu/food-menu/food-menu.component';
import { FoodItemEditComponent } from '../food/item-edit/food-item-edit/food-item-edit.component';
import { FoodSearchComponent } from 'src/food/search/food-search/food-search.component';
import { FoodItemInfoComponent } from '../food/item-info/food-item-info/food-item-info.component';
import { FoodMenuAdminComponent } from '../food/menu/food-menu-admin/food-menu-admin.component';
import { FoodMenuCustomerComponent } from '../food/menu/food-menu-customer/food-menu-customer.component';
import { LoginComponent } from './site/login/login.component';
import { ShoppingCartComponent } from 'src/shopping/cart/shopping-cart/shopping-cart.component';
import { SignUpComponent } from './site/sign-up/sign-up.component';

@NgModule({
  declarations: [
    AppComponent,
    FoodMenuComponent,
    FoodSearchComponent,
    FoodItemEditComponent,
    FoodItemInfoComponent,
    FoodMenuAdminComponent,
    FoodMenuCustomerComponent,
    LoginComponent,
    ShoppingCartComponent,
    SignUpComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
