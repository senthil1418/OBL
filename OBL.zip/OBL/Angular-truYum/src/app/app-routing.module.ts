import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FoodItemEditComponent } from 'src/food/item-edit/food-item-edit/food-item-edit.component';
import { FoodMenuAdminComponent } from 'src/food/menu/food-menu-admin/food-menu-admin.component';
import { FoodMenuCustomerComponent } from 'src/food/menu/food-menu-customer/food-menu-customer.component';
import { AuthGuardService } from './auth-guard.service';
import { LoginComponent } from './site/login/login.component';
import { AppComponent } from './app.component';
import { ShoppingCartComponent } from 'src/shopping/cart/shopping-cart/shopping-cart.component';
import { SignUpComponent } from './site/sign-up/sign-up.component';
import { FoodItemInfoComponent } from '../food/item-info/food-item-info/food-item-info.component';
import { FoodMenuComponent } from '../food/menu/food-menu/food-menu.component';


const routes: Routes = [
  {
  path:'Login',
  component:LoginComponent
  },
  {
    path:'SignUp',
    component:SignUpComponent
    },
  {
    path:'Home',
    component:AppComponent
  },
  {
    path:'FoodItemsAdmin',
    component:FoodMenuAdminComponent, 
    canActivate: [AuthGuardService]
},

 {
   path:'FoodItemsCustomer',
 component:FoodMenuCustomerComponent, 
 canActivate: [AuthGuardService]
 },
{
  path:'menuItem',
  component:FoodMenuComponent
},
 {path:'EditFood/:id',
 component:FoodItemEditComponent},
 {
   path:'Cart',
   component:ShoppingCartComponent
 },
 {
   path:'foodItem',
   component:FoodItemInfoComponent
 }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
