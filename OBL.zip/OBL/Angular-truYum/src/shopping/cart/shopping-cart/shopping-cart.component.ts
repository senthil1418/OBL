import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/shopping/cart.service';
import { ICartItems } from '../ICartItems.Module';
import { IFooditem } from 'src/food/IFoodItem.Module';
//import { checkServerIdentity } from 'tls';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {

  constructor(private _authService:AuthService,private _router:Router,private cartService:CartService) { }
  total:number;
  cart:ICartItems;
  ngOnInit() {
    this.cart=this.cartService.getCart();
    this.total=this.cartService.totalCalculate();
    
  }
delete(item:IFooditem):void{
  const index: number = this.cart.cartItems.indexOf(item);
    if (index !== -1) {
        this.cart.cartItems.splice(index, 1);
        this.total=this.cartService.totalCalculate();  
        
    }
}
url:string="src/shopping/cart/cart-empty.html";
check():boolean{
  
  if(this.cartService.totalCalculate()==0)
  {
    return false;
  }
  else
  {
    return true;
  }
}
logOut():void
   {
     this._authService.logOut();
     //this.route.navigate(['/']);
   }
}
