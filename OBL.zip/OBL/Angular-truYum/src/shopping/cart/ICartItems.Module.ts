import { IFooditem } from 'src/food/IFoodItem.Module';

export interface ICartItems 
{
    cartItems:IFooditem[];
    total:number;
}