import { Injectable } from '@angular/core';
import { ICartItems } from './cart/ICartItems.Module';
import { IFooditem } from 'src/food/IFoodItem.Module';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor() { }
  totalPrice:number=0;
  cart:ICartItems={
      
    cartItems:[
      {id:101,name:"Sandwich",price:99,active:"Yes",date_of_launch:new Date('5/03/2017'),category:"Main Course",free_delivery:true,photopath:"https://bit.ly/2zHxVWJ"},
      {id:102,name:"Burger",price:129,active:"Yes",date_of_launch:new Date('3/12/2017'),category:"Main Course",free_delivery:true,photopath:"https://bit.ly/2LjCWKe"}],
      total:0}

  
  getCart():ICartItems
  {
    this.totalCalculate();
    return this.cart;
   
  }
  totalCalculate():number{
    this.totalPrice=0;
    for (let items of this.cart.cartItems) 
    {
     this.totalPrice+=items.price;
    }
    return this.totalPrice;
  }
  cartUpdated():boolean
  {
    return true;
  }

  addToCart(item:IFooditem):void
  { 
    console.log(item) ;  
    this.cart.cartItems.push(item);   
    console.log(this.cart.cartItems);
   
  }
}
