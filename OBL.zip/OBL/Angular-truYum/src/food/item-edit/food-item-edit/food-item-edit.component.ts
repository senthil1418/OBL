import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FoodServiceService } from 'src/food/food-service.service';
import { IFooditem } from 'src/food/IFoodItem.Module';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-food-item-edit',
  templateUrl: './food-item-edit.component.html',
  styleUrls: ['./food-item-edit.component.css']
})
export class FoodItemEditComponent implements OnInit {
  menuItem:IFooditem;
  menuItems:IFooditem[];
  constructor(private _authService:AuthService,private router:Router,private route:ActivatedRoute,foodService:FoodServiceService) {
    this.menuItems=foodService.getMenuItems();
   }
   flag:boolean=false;
  
  ngOnInit() {
    const mid = +this.route.snapshot.paramMap.get('id');
    this.menuItem=this.menuItems.find(e=>e.id==mid);
    console.log(this.menuItem);
  }
  updateFoodItem(newmenuItem:IFooditem):void{
    const index: number = this.menuItems.indexOf(this.menuItem);
    if (index !== -1) {
        this.menuItems.splice(index, 1,newmenuItem);
        
    }
    this.flag=true;
    console.log(newmenuItem);
  }
  logOut():void
  {
    this._authService.logOut();
    this.router.navigate(['/']);
  }

}
