import { Component, OnInit } from '@angular/core';
import { IFooditem } from 'src/food/IFoodItem.Module';
import { FoodServiceService } from 'src/food/food-service.service';

@Component({
  selector: 'app-food-search',
  templateUrl: './food-search.component.html',
  styleUrls: ['./food-search.component.css']
})
export class FoodSearchComponent implements OnInit {

  searchKey:string="";
  filteredItems:IFooditem[];
  menuItems:IFooditem[];
  constructor(private foodService:FoodServiceService) {
    this.menuItems=foodService.getMenuItems();
   }
  ngOnInit() {
    this.filteredItems=this.menuItems;
  }

  search():void{

    this.filteredItems=this.foodService.getMenuItem(this.searchKey);
   }

}
