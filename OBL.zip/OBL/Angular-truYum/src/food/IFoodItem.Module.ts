export interface IFooditem
{
    cartid?:number;
    id:number;
    name	:string;
    price	:number;
    active	:string;
    date_of_launch	:Date;
    category:string;
    free_delivery:boolean	;
    photopath:string;
}