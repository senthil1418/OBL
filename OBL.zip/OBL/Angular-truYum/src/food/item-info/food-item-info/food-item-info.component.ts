import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-item-info',
  templateUrl: './food-item-info.component.html',
  styleUrls: ['./food-item-info.component.css']
})
export class FoodItemInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
