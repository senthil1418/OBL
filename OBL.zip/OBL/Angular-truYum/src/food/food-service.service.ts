import { Injectable } from '@angular/core';
import { IFooditem } from './IFoodItem.Module';

@Injectable({
  providedIn: 'root'
})
export class FoodServiceService {

  constructor() { }
public menuItem:IFooditem[]=[
  {id:101,name:"Sandwich",price:99,active:"Yes",date_of_launch:new Date('5/03/2017'),category:"Main Course",free_delivery:true,photopath:"https://bit.ly/2zHxVWJ"},
  {id:102,name:"Burger",price:129,active:"Yes",date_of_launch:new Date('3/12/2017'),category:"Main Course",free_delivery:true,photopath:"https://bit.ly/2LjCWKe"},
  {id:103,name:"Pizza",price:149,active:"Yes",date_of_launch:new Date('1/08/2018'),category:"Main Course",free_delivery:false,photopath:"https://bit.ly/2PosnuC"},
  {id:104,name:"French Fries",price:57,active:"No",date_of_launch:new Date('02/07/2017'),category:"Starters",free_delivery:true,photopath:"https://bit.ly/2Larbak"},
  {id:105,name:"Chocolate Brownie",price:32,active:"Yes",date_of_launch:new Date('02/11/2022'),category:"Desert",free_delivery:true,photopath:"https://bit.ly/2Pzkdj4"}
]
searchKey:string;
getMenuItems():IFooditem[]
{
  return this.menuItem;
}
getMenuItem(search:string):IFooditem[]
{
 this.searchKey=search;
 return this.menuItem.filter(x=>x.name.toLowerCase().indexOf(this.searchKey.toLowerCase())!==-1);

}
}
