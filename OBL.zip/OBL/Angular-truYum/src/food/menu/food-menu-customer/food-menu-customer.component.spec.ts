import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodMenuCustomerComponent } from './food-menu-customer.component';

describe('FoodMenuCustomerComponent', () => {
  let component: FoodMenuCustomerComponent;
  let fixture: ComponentFixture<FoodMenuCustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodMenuCustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodMenuCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
