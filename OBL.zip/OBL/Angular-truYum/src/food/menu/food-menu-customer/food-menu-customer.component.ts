import { Component, OnInit } from '@angular/core';
import { FoodServiceService } from 'src/food/food-service.service';
import { Router, Route } from '@angular/router';
import { IFooditem } from 'src/food/IFoodItem.Module';
import { AuthService } from 'src/app/auth.service';
import { ICartItems } from 'src/shopping/cart/ICartItems.Module';
import { CartService } from 'src/shopping/cart.service';

@Component({
  selector: 'app-food-menu-customer',
  templateUrl: './food-menu-customer.component.html',
  styleUrls: ['./food-menu-customer.component.css']
})
export class FoodMenuCustomerComponent implements OnInit {
  constructor(private _router:Router,private foodService:FoodServiceService,private cartService:CartService,private route:Router,private _authService:AuthService) { }
  menuItems:IFooditem[];
  ngOnInit() {
    this.menuItems=this.foodService.getMenuItems();
    this.filteredItems=this.menuItems;
  }

  searchKey:string="";
  filteredItems:IFooditem[];
  cart:ICartItems;
flag:boolean=false;
id:number;

  search():void{
    this.filteredItems=this.foodService.getMenuItem(this.searchKey)
   }

   logOut():void
   {
     this._authService.logOut();
     //this.route.navigate(['/']);
   }
   addToCart(item:IFooditem):void
   { 
     this.flag=false;
     this.id=0;
     this.cartService.addToCart(item);
    //  console.log(item) ;  
    // this.cartService.cart.cartItems.push(item);   

    // console.log(this.cartService.cart.cartItems);
    //this._router.navigate(['Cart']);
    this.id=item.id;
    this.flag=true;
   }
}
