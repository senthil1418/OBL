import { Component, OnInit } from '@angular/core';
import { FoodServiceService } from 'src/food/food-service.service';
import { IFooditem } from 'src/food/IFoodItem.Module';

@Component({
  selector: 'app-food-menu',
  templateUrl: './food-menu.component.html',
  styleUrls: ['./food-menu.component.css']
})
export class FoodMenuComponent implements OnInit {

  constructor(private foodService:FoodServiceService) { }
  menuItems:IFooditem[];
  ngOnInit() {
    this.menuItems=this.foodService.getMenuItems();
  }

}
