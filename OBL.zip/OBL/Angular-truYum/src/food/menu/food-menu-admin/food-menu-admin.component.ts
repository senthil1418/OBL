import { Component, OnInit } from '@angular/core';
import { FoodServiceService } from 'src/food/food-service.service';
import { IFooditem } from 'src/food/IFoodItem.Module';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-food-menu-admin',
  templateUrl: './food-menu-admin.component.html',
  styleUrls: ['./food-menu-admin.component.css']
})
export class FoodMenuAdminComponent implements OnInit {


  constructor(private foodService:FoodServiceService,private route:Router,private _authService:AuthService) { }
  menuItems:IFooditem[];
  ngOnInit() {
    this.menuItems=this.foodService.getMenuItems();
    this.filteredItems=this.menuItems;
  }
  // edit(id:number):void{
  //   this.route.navigate(['/EditFood',id]);
  // }
  searchKey:string="";
  filteredItems:IFooditem[];
  


  search():void{

    this.filteredItems=this.foodService.getMenuItem(this.searchKey)
    //this.filteredItems= this.menuItems.filter(x=>x.name.toLowerCase().indexOf(this.searchKey.toLowerCase())!==-1);
 
   }
   logOut():void
   {
     this._authService.logOut();
     this.route.navigate(['/']);
   }
}
