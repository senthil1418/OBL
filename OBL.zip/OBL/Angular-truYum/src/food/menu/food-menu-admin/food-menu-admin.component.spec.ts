import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodMenuAdminComponent } from './food-menu-admin.component';

describe('FoodMenuAdminComponent', () => {
  let component: FoodMenuAdminComponent;
  let fixture: ComponentFixture<FoodMenuAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodMenuAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodMenuAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
