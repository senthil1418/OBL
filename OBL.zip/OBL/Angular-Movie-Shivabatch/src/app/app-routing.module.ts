import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MovieCruiserEditComponent } from './movie/movie-cruiser-edit/movie-cruiser-edit.component';
import { MovieCruiserInfoComponent } from './movie/movie-cruiser-info/movie-cruiser-info.component';

import { MovieSearchComponent } from './movie/movie-search/movie-search.component';
import { MoviesListComponent } from './movie/movies-list/movies-list.component';

import { MovieFavoritesComponent } from './wishlist/movie-favorites/movie-favorites.component';
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component';
import { AuthServiceGuardGuard } from './site/auth-service.guard';


const routes: Routes = [
  { path: 'movie-cruiser-edit/:id', component: MovieCruiserEditComponent, canActivate: [AuthServiceGuardGuard] },
  { path: 'movie-cruiser-info', component: MovieCruiserInfoComponent },
  { path: 'movies-list', component: MoviesListComponent },
  { path: 'movie-search', component: MovieSearchComponent },
  { path: 'movie-favorites', component: MovieFavoritesComponent, canActivate: [AuthServiceGuardGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: '', redirectTo: 'movie-search', pathMatch: 'full' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


}
