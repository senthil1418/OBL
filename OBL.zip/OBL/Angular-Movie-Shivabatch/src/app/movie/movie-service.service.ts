import { Injectable } from '@angular/core';
import { Movies } from './movies';
import { AuthServiceService } from '../site/auth-service.service';

@Injectable({
  providedIn: 'root'
})
export class MovieServiceService {

  movie: Movies[] = [

    { id: 1, name: "Avatar", boxOffice: 2787965087, isAvailable: true, dateOfLaunch: new Date("03/15/2017"), genre: "Science Fiction", hasTeaser: true, url: "https://wegotthiscovered.com/wp-content/uploads/2018/01/Avatar.jpg" },
    { id: 2, name: "The Avengers", boxOffice: 1518812988, isAvailable: true, dateOfLaunch: new Date("12/23/2017"), genre: "SuperHero", hasTeaser: false, url: "https://img.hdv.fun/backdrop/tt0848228.jpg" },
    { id: 3, name: "Titanic", boxOffice: 2187463944, isAvailable: true, dateOfLaunch: new Date("08/21/2017"), genre: "Romance", hasTeaser: false, url: "https://media1.fdncms.com/metrotimes/imager/u/original/7131319/1280x720-tu3.jpg" },
    { id: 4, name: "Jurassic World", boxOffice: 1671713208, isAvailable: false, dateOfLaunch: new Date("07/02/2017"), genre: "Science Fiction", hasTeaser: true, url: "http://s1.1zoom.me/b5050/37/Dinosaurs_Jurassic_Park_440745_1280x720.jpg" },
    { id: 5, name: "Avengers: End Game", boxOffice: 2750760348, isAvailable: true, dateOfLaunch: new Date("11/02/2022"), genre: "SuperHero", hasTeaser: true, url: "https://www.whats-on-netflix.com/wp-content/uploads/2019/04/Marvel-Avengers-Endgame.jpg" }


  ];

  constructor(private service: AuthServiceService) { }
  getMovies(active: boolean = true, date: Date = new Date()) {
    let filteredmovie = this.movie.filter(x => x.isAvailable == active && x.dateOfLaunch < date)
    return filteredmovie;
  }
  getAllMovies() {
    return this.movie;
  }

  getMoviesById(id: number): Movies {
    for (let list of this.movie) {
      if (list.id == id) {
        return list;
      }
    } return null;
  }

  getMovies1(ss: string) {
    if (this.service.isAdmin()) {
      if (ss == '') {
        return this.getAllMovies();
      }
      else {
        let filteredmovie = this.movie.filter(x => x.name.toLowerCase().indexOf(ss.toLowerCase()) !== -1)
        return filteredmovie;

      }
    }
    else {
      if (ss == '') {
        return this.getMovies();
      }
      else {
        let filteredmovie = this.getMovies().filter(x => x.name.toLowerCase().indexOf(ss.toLowerCase()) !== -1)
        return filteredmovie;

      }
    }


  }

  updateMovies(editmovie: Movies) {
    for (var list of this.movie) {
      if (list.id == editmovie.id) {
        list.name = editmovie.name;
        list.boxOffice = editmovie.boxOffice;
        list.isAvailable = editmovie.isAvailable;
        list.dateOfLaunch = editmovie.dateOfLaunch;
        list.genre = editmovie.genre;
        list.hasTeaser = editmovie.hasTeaser;
      }
    } return list;

  }

}
