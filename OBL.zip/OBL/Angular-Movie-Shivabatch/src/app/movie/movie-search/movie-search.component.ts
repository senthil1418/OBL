import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from 'src/app/site/auth-service.service';
import { Router } from '@angular/router';
import { MovieServiceService as MovieService } from '../movie-service.service';
import { Movies } from '../movies'

@Component({
  selector: 'app-movie-search',
  templateUrl: './movie-search.component.html',
  styleUrls: ['./movie-search.component.css']
})
export class MovieSearchComponent implements OnInit {
  searchtext: string;
  movie: Movies[];
  islogged: boolean;
  username: string = this.service2.getUserName();
  iscustomer: boolean = this.service2.isAdmin();

  constructor(public service: MovieService, private service2: AuthServiceService, private router: Router) { }

  ngOnInit() {
    this.islogged = this.service2.isLogged();
  }
  search() {
    this.movie = this.service.getMovies1(this.searchtext);
  }
  logout() {
    this.service2.logout();
    this.username = this.service2.getUserName();
    this.router.navigateByUrl('/login');
  }


}

