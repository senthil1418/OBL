import { Component, OnInit, Input } from '@angular/core';
import { MovieServiceService } from '../movie-service.service';
import { Movies } from '../movies';

@Component({
  selector: 'app-movies-list',
  templateUrl: './movies-list.component.html',
  styleUrls: ['./movies-list.component.css']
})
export class MoviesListComponent implements OnInit {

  @Input()
  public movies: Movies[];

  constructor(public service: MovieServiceService) {
  }

  ngOnInit() {
    this.movies = this.service.getMovies();
  }

}
