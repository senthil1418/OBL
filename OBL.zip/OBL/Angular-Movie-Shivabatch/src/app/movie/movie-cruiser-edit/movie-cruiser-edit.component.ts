import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from "@angular/router";
import { AuthServiceService } from 'src/app/site/auth-service.service';
import { Movies } from '../movies';
import { MovieServiceService } from '../movie-service.service'

@Component({
  selector: 'app-movie-cruiser-edit',
  templateUrl: './movie-cruiser-edit.component.html',
  styleUrls: ['./movie-cruiser-edit.component.css']
})
export class MovieCruiserEditComponent implements OnInit {

  constructor(private service : MovieServiceService,private service2 : AuthServiceService,private route: ActivatedRoute) { }
editForm:FormGroup;
movieId = this.route.snapshot.paramMap.get('id');
favorites:Movies;
editted:boolean=false;

  ngOnInit() {
    
    let mid=Number(this.movieId);
    console.log(this.movieId);
    this.favorites = this.service.getMoviesById(mid);
    this.editForm = new FormGroup({
      'name' : new FormControl(this.favorites.name, [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(20)
      ]),
      'boxOffice' : new FormControl(this.favorites.boxOffice, [
        Validators.required,
        Validators.pattern("^[0-9]*$")
      ]),
      'isAvailable' : new FormControl(this.favorites.isAvailable, [
        Validators.required,
      ]),
      'dateOfLaunch' : new FormControl(this.favorites.dateOfLaunch, [
        Validators.required,
      ]),
      'genre' : new FormControl(this.favorites.genre, [
        Validators.required,
      ]),
      'hasTeaser' : new FormControl(this.favorites.hasTeaser, [
      ]),

    });
    this.editForm.get('name').valueChanges.subscribe(value=>this.favorites.name=value);
    this.editForm.get('boxOffice').valueChanges.subscribe(value=>this.favorites.boxOffice=value);
    this.editForm.get('isAvailable').valueChanges.subscribe(value=>this.favorites.isAvailable=value);
    this.editForm.get('dateOfLaunch').valueChanges.subscribe(value=>this.favorites.dateOfLaunch=value);
    this.editForm.get('genre').valueChanges.subscribe(value=>this.favorites.genre=value);
    this.editForm.get('hasTeaser').valueChanges.subscribe(value=>this.favorites.hasTeaser=value);
    
  }
  onSubmit(){
    this.service.updateMovies(this.favorites);
    this.editted=true;
  }
  get name() { return this.editForm.get('name'); }
   get boxOffice() { return this.editForm.get('boxOffice'); }
   get isAvailable() { return this.editForm.get('isAvailable'); }
   get dateOfLaunch() { return this.editForm.get('dateOfLaunch'); }
   get genre() { return this.editForm.get('genre'); }
   get hasTeaser() { return this.editForm.get('hasTeaser'); }



}
