import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MovieCruiserEditComponent } from './movie-cruiser-edit.component';

describe('MovieCruiserEditComponent', () => {
  let component: MovieCruiserEditComponent;
  let fixture: ComponentFixture<MovieCruiserEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MovieCruiserEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MovieCruiserEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
