export interface Movies {

    id: number;
    name: string;
    boxOffice: number;
    isAvailable: boolean;
    dateOfLaunch: Date;
    genre: string;
    hasTeaser: boolean;
    url: string;

}
