import { Component, OnInit, Input } from '@angular/core';
import { AuthServiceService } from 'src/app/site/auth-service.service';
import { Router } from '@angular/router';
import { Movies } from '../movies';
import { MovieServiceService } from '../movie-service.service';
import { FavoritesServiceService } from 'src/app/wishlist/favorites-service.service';

@Component({
  selector: 'app-movie-cruiser-info',
  templateUrl: './movie-cruiser-info.component.html',
  styleUrls: ['./movie-cruiser-info.component.css']
})
export class MovieCruiserInfoComponent implements OnInit {
  temp: boolean = true;
  isAdmin: boolean = false;
  added: boolean = false;
  @Input() movie: Movies[];
  constructor(public service: FavoritesServiceService, public service1: MovieServiceService, public service2: AuthServiceService, private router: Router) {
  }

  ngOnInit() {
    this.isAdmin = this.service2.isAdmin();
    if (this.isAdmin) {
      this.movie = this.service1.getAllMovies();
    }
    else {
      this.movie = this.service1.getMovies();
    }
  }
  addToFavorites(item: Movies) {
    if (this.service2.isLogged()) {
      this.service.addToFavorites(item);
      this.added = true;

    } else {
      this.router.navigateByUrl('/login');
    }
  }



}
