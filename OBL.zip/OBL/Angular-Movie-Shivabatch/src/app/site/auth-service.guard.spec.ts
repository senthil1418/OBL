import { TestBed, async, inject } from '@angular/core/testing';

import { AuthServiceGuardGuard } from './auth-service.guard';

describe('AuthServiceGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthServiceGuardGuard]
    });
  });

  it('should ...', inject([AuthServiceGuardGuard], (guard: AuthServiceGuardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
