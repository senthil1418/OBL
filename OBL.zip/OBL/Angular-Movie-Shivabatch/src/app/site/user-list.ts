export interface UserList {
    username:string,
    firstname:string,
    lastname:string,
    password:string,
    confirm_password:string;
}
