import { Injectable } from '@angular/core';
import { UserList } from './user-list';
import { UserServiceService } from './user-service.service';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  loggedInUser: boolean;
  user: UserList[];
  adminflag: boolean = false;
  loggedusername: string;
  constructor(private service: UserServiceService) { }
  getUserName() {
    return this.loggedusername;
  }
  logout() {
    this.loggedInUser = false;
    this.adminflag = false;

  }
  isLogged() {
    return this.loggedInUser;
  }

  authenticateUser(username: string, password: string) {
    this.user = this.service.getAllUser();
    var flag: boolean;
    for (let user of this.user) {
      if (user.username == username && user.password == password) {
        flag = true;
        break;
      }
      else {
        flag = false;
      }
    }
    this.loggedusername = username;
    this.loggedInUser = true;

    if (username == 'Admin' && password == 'pass') {
      this.adminflag = true;
    }
    else {
      this.adminflag = false;
    }
    if (flag) {
      return true;
    }
    else {
      return false;
    }
    
  }
  isAdmin() {
    return this.adminflag;
  }
}
