import { Injectable } from '@angular/core';
import { UserList } from './user-list';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  user:UserList[]=[{username:"Admin",firstname:"admin",lastname:"admin",password:"pass",confirm_password:"pass"},
  {username:"Nive",firstname:"Nive",lastname:"E",password:"1234",confirm_password:"1234"}];

  constructor() { }
  adduser(newuser:UserList){
    this.user.push(newuser);
    console.log(newuser);
  }
  getAllUser(){
    return this.user;
  }
  getUser(username:string): UserList{
    for(let userlist of this.user){
      if(userlist.username==username){
       
        return userlist;
      }
      else{
        
      }
    }
  }
}
