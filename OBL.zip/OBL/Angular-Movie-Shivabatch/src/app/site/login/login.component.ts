import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../auth-service.service';
import { UserList } from '../user-list';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  authenticated:boolean=true;
  loggeduser:UserList;
  constructor(private service: AuthServiceService,public router: Router) { }

  ngOnInit() {
    this.loggeduser={
      username:"",
      firstname:"",
      lastname:"",
      password:"",
      confirm_password:""
    }
  }
  onlogin(){
    console.log(this.loggeduser.username);
    this.authenticated=this.service.authenticateUser(this.loggeduser.username,this.loggeduser.password);
    if(this.authenticated) {
      this.router.navigateByUrl('/movie-search');
    }
    else this.router.navigateByUrl('/login');

  }

}
