import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { MovieServiceService as MovieService } from '../app/movie/movie-service.service';

import { MovieCruiserEditComponent } from './movie/movie-cruiser-edit/movie-cruiser-edit.component';
import { MovieCruiserInfoComponent } from './movie/movie-cruiser-info/movie-cruiser-info.component';

import { MovieSearchComponent } from './movie/movie-search/movie-search.component';
import { MoviesListComponent } from './movie/movies-list/movies-list.component';

import { MovieFavoritesComponent } from './wishlist/movie-favorites/movie-favorites.component';
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component';

@NgModule({
  declarations: [
    AppComponent,
    MovieCruiserEditComponent,
    MovieCruiserInfoComponent,

    MovieSearchComponent,
    MoviesListComponent,

    MovieFavoritesComponent,
    LoginComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [MovieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
