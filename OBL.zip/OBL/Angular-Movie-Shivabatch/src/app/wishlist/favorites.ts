import { Movies } from "src/app/movie/movies";

export interface Favorites {

    movies:Movies[],
    total:number;


}
