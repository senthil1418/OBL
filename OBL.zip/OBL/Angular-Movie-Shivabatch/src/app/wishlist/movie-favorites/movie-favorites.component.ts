import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from 'src/app/site/auth-service.service';
import { FavoritesServiceService } from '../favorites-service.service';
import { Favorites } from '../favorites';

@Component({
  selector: 'app-movie-favorites',
  templateUrl: './movie-favorites.component.html',
  styleUrls: ['./movie-favorites.component.css']
})
export class MovieFavoritesComponent implements OnInit {

  isFavoritesEmpty: boolean;
  temp: boolean = true;
  constructor(private service: FavoritesServiceService, private service2: AuthServiceService) { }
  displayfavorite: Favorites;
  iscustomer: boolean = this.service2.isAdmin();
  username: string = this.service2.getUserName();

  ngOnInit() {
    this.displayfavorite = this.service.getFavorites();
  }
  getTotal() {
    return this.service.totalcalc();
  }
  removeFavorites(id: number) {
    this.temp = false;
    this.service.removeFavorites(id);
    if (this.displayfavorite.total == 0) {
      this.isFavoritesEmpty = true;
    } else {
      this.isFavoritesEmpty = false;
    }

  }

}
