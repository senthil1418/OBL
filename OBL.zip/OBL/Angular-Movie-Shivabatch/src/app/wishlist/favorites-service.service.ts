import { Injectable } from '@angular/core';
import { Favorites } from '../wishlist/favorites';
import { Movies } from '../movie/movies';

@Injectable({
  providedIn: 'root'
})
export class FavoritesServiceService {

  favorite: Favorites = {
    movies: [
      {
        id: 1,
        name: "Avatar",
        boxOffice: 2787965087,
        isAvailable: true,
        dateOfLaunch: new Date("03/15/2017"),
        genre: "Science Fiction",
        hasTeaser: true,
        url: "https://wegotthiscovered.com/wp-content/uploads/2018/01/Avatar.jpg"
      },
      { id: 2, 
        name: "The Avengers", 
        boxOffice: 1518812988, 
        isAvailable: true, 
        dateOfLaunch: new Date("12/23/2017"), 
        genre: "SuperHero", 
        hasTeaser: false, 
        url: "https://img.hdv.fun/backdrop/tt0848228.jpg" },
      { id: 3, 
        name: "Titanic", 
        boxOffice: 2187463944, 
        isAvailable: true, 
        dateOfLaunch: new Date("08/21/2017"), 
        genre: "Romance", 
        hasTeaser: false,
        url: "https://media1.fdncms.com/metrotimes/imager/u/original/7131319/1280x720-tu3.jpg" }
    ],
    total: 0
  };

  constructor() { }

  getFavorites() {
    return this.favorite;
  }

  addToFavorites(favorite_item: Movies) {
    this.favorite.movies.push(favorite_item);
    this.totalcalc();
    console.log(this.favorite);
  }

  totalcalc() {
    let count = 0;
    for (let fav of this.favorite.movies) {
      count++;

    }
    this.favorite.total = count;
    return this.favorite.total;
  }

  removeFavorites(id: number) {
    const index = this.favorite.movies.findIndex(movie => movie.id == id);
    const itemToRemove = this.favorite.movies.splice(index, 1)[0];
    this.favorite.total--;
  }
}
