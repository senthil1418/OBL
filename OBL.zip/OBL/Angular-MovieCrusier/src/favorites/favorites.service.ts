import { Injectable } from '@angular/core';
import { IFavoriteItems } from './IfavoriteItems';
import { IMovieItem } from 'src/movies/IMovieItem.module';

@Injectable({
  providedIn: 'root'
})
export class FavoritesService {

  constructor() { }
  totalPrice:number=0;
  favorites:IFavoriteItems={
      
    favoritesItems:[
      {id:101,name:"Avengers",price:356000000,active:"Yes",date_of_launch:new Date('4/26/2019'),genre:"Action",hasteaser:true,photopath:"https://i2.wp.com/metro.co.uk/wp-content/uploads/2019/04/SEI_59607150-e1555398387827.jpg?quality=90&strip=all&zoom=1&resize=644%2C428&ssl=1"},
     {id:102,name:"Aladdin",price:183000000,active:"Yes",date_of_launch:new Date('4/26/2019'),genre:"Adeventure",hasteaser:false,photopath:"https://lumiere-a.akamaihd.net/v1/images/aladdin-payoff-mobile-hero_5bf2644f.jpeg"}],
      total:0}
  getFavorites():IFavoriteItems
  {
    this.totalCalculate();
    return this.favorites;
   
  }
  totalCalculate():number{
    this.totalPrice=0;
    for (let items of this.favorites.favoritesItems) 
    {
     this.totalPrice+=1;
    }
    return this.totalPrice;
  }
  FavoritesUpdated():boolean
  {
    return true;
  }

  addToFavorites(item:IMovieItem):void
  { 
    console.log(item) ;  
    this.favorites.favoritesItems.push(item);   
    console.log(this.favorites.favoritesItems);
   
  }
}
