import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth.service';
import { Router } from '@angular/router';
import { FavoritesService } from '../favorites.service';
import { IFavoriteItems } from '../IfavoriteItems';
import { IMovieItem } from 'src/movies/IMovieItem.module';

@Component({
  selector: 'app-movie-favorites',
  templateUrl: './movie-favorites.component.html',
  styleUrls: ['./movie-favorites.component.css']
})
export class MovieFavoritesComponent implements OnInit {

  constructor(private _authService:AuthService,private _router:Router,private favoritesService:FavoritesService) { }
  total:number;
  favorites:IFavoriteItems;
  ngOnInit() {
    this.favorites=this.favoritesService.getFavorites();
    this.total=this.favoritesService.totalCalculate();
    
  }
delete(item:IMovieItem):void{
  const index: number = this.favorites.favoritesItems.indexOf(item);
    if (index !== -1) {
        this.favorites.favoritesItems.splice(index, 1);
        this.total=this.favoritesService.totalCalculate();  
        
    }
}

check():boolean{
  
  if(this.favoritesService.totalCalculate()==0)
  {
    return false;
  }
  else
  {
    return true;
  }
}
logOut():void
   {
     this._authService.logOut();
     //this.route.navigate(['/']);
   }
}
