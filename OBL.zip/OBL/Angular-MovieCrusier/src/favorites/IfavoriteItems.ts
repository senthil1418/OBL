import { IMovieItem } from 'src/movies/IMovieItem.module';

export interface IFavoriteItems 
{
    favoritesItems:IMovieItem[];
    total:number;
}