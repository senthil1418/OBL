import { Component, OnInit } from '@angular/core';
import { MoviesService } from 'src/movies/movies.service';
import { IMovieItem } from 'src/movies/IMovieItem.module';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {

 
  constructor(private movieService:MoviesService) { }
  movieItems:IMovieItem[];
  ngOnInit() {
    this.movieItems=this.movieService.getMovieItems();
  }

}
