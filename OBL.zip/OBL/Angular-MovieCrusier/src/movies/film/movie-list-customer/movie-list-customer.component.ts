import { Component, OnInit } from '@angular/core';
import { FavoritesService } from 'src/favorites/favorites.service';
import { MoviesService } from 'src/movies/movies.service';
import { Router } from '@angular/router';
import { IMovieItem } from 'src/movies/IMovieItem.module';
import { AuthService } from 'src/app/auth.service';
import { IFavoriteItems } from 'src/favorites/IfavoriteItems';

@Component({
  selector: 'app-movie-list-customer',
  templateUrl: './movie-list-customer.component.html',
  styleUrls: ['./movie-list-customer.component.css']
})
export class MovieListCustomerComponent implements OnInit {

  constructor(private _router:Router,private movieService:MoviesService,private favoritesService:FavoritesService,private route:Router,private _authService:AuthService) { }
  movieItems:IMovieItem[];
  ngOnInit() {
    this.movieItems=this.movieService.getMovieItems();
    this.filteredItems=this.movieItems;
  }

  searchKey:string="";
  filteredItems:IMovieItem[];
  favorites:IFavoriteItems;
flag:boolean=false;
id:number;

  search():void{
    this.filteredItems=this.movieService.getMovieItem(this.searchKey)
   }

   logOut():void
   {
     this._authService.logOut();
     //this.route.navigate(['/']);
   }
   addToFavorites(item:IMovieItem):void
   { 
     this.flag=false;
     this.id=0;
     this.favoritesService.addToFavorites(item);
   
    this.id=item.id;
    this.flag=true;
   }
}
