import { Component, OnInit } from '@angular/core';
import { MoviesService } from 'src/movies/movies.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { IMovieItem } from 'src/movies/IMovieItem.module';

@Component({
  selector: 'app-movie-list-admin',
  templateUrl: './movie-list-admin.component.html',
  styleUrls: ['./movie-list-admin.component.css']
})
export class MovieListAdminComponent implements OnInit {

  constructor(private movieService:MoviesService,private route:Router,private _authService:AuthService) { }
  movieItems:IMovieItem[];
  ngOnInit() {
    this.movieItems=this.movieService.getMovieItems();
    this.filteredItems=this.movieItems;
  }
  // edit(id:number):void{
  //   this.route.navigate(['/EditFood',id]);
  // }
  searchKey:string="";
  filteredItems:IMovieItem[];
  


  search():void{

    this.filteredItems=this.movieService.getMovieItem(this.searchKey)
    //this.filteredItems= this.menuItems.filter(x=>x.name.toLowerCase().indexOf(this.searchKey.toLowerCase())!==-1);
 
   }
   logOut():void
   {
     this._authService.logOut();
     this.route.navigate(['/']);
   }

}
