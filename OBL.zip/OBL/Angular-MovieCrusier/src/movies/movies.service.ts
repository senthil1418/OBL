import { Injectable } from '@angular/core';
import { IMovieItem } from './IMovieItem.module';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  constructor() { }
  public movieitem:IMovieItem[]=[
     {id:101,name:"Avengers",price:356000000,active:"Yes",date_of_launch:new Date('4/26/2019'),genre:"Action",hasteaser:true,photopath:"https://i2.wp.com/metro.co.uk/wp-content/uploads/2019/04/SEI_59607150-e1555398387827.jpg?quality=90&strip=all&zoom=1&resize=644%2C428&ssl=1"},
     {id:102,name:"Aladdin",price:183000000,active:"Yes",date_of_launch:new Date('4/26/2019'),genre:"Adventure",hasteaser:false,photopath:"https://lumiere-a.akamaihd.net/v1/images/aladdin-payoff-mobile-hero_5bf2644f.jpeg"},
     {id:103,name:"Captain Marvel",price:173000000,active:"Yes",date_of_launch:new Date('4/26/2019'),genre:"Action",hasteaser:true,photopath:"https://fever.imgix.net/plan/photo/e062ff88-3e9c-11e9-ac07-067dfd978c4d.jpg?auto=compress&auto=format&fm=jpg&w=550&h=550"},
     {id:104,name:"The Lion King",price:45000000,active:"No",date_of_launch:new Date('4/26/2019'),genre:"Animation",hasteaser:false,photopath:"https://cdn.shopify.com/s/files/1/0798/5303/products/LION_KINGfebfc653eb_o_1_1024x1024@2x.jpg?v=1514747994"},
     {id:105,name:"First Man",price:70000000,active:"Yes",date_of_launch:new Date('4/26/2019'),genre:"Adventure",hasteaser:true,photopath:"https://i.ebayimg.com/images/g/zyIAAOSwsGpbzMHs/s-l300.jpg"}
  ]
  searchKey:string;
getMovieItems():IMovieItem[]
{
  return this.movieitem;
}
getMovieItem(search:string):IMovieItem[]
{
 this.searchKey=search;
 return this.movieitem.filter(x=>x.name.toLowerCase().indexOf(this.searchKey.toLowerCase())!==-1);

}
}
