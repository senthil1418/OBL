export interface IMovieItem
{
    favoriteid?:number;
    id:number;
    name	:string;
    price	:number;
    active	:string;
    date_of_launch	:Date;
    genre:string;
    hasteaser:boolean	;
    photopath:string;
}