import { Component, OnInit } from '@angular/core';
import { IMovieItem } from '../IMovieItem.module';
import { MoviesService } from '../movies.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchKey:string="";
  filteredItems:IMovieItem[];
  movieItems:IMovieItem[];
  constructor(private movieService:MoviesService) {
    this.movieItems=movieService.getMovieItems();
   }

  ngOnInit() {
    this.filteredItems=this.movieItems;
  }
  search():void{

    this.filteredItems=this.movieService.getMovieItem(this.searchKey);
   }

}
