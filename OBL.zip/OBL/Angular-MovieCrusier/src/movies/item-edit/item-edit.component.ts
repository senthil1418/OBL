import { Component, OnInit } from '@angular/core';
import { IMovieItem } from '../IMovieItem.module';
import { AuthService } from 'src/app/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MoviesService } from '../movies.service';

@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.css']
})
export class ItemEditComponent implements OnInit {

  movieItem:IMovieItem;
  movieItems:IMovieItem[];
  constructor(private _authService:AuthService,private router:Router,private route:ActivatedRoute,movieService:MoviesService) {
    this.movieItems=movieService.getMovieItems();
   }
   flag:boolean=false;
  
  ngOnInit() {
    const mid = +this.route.snapshot.paramMap.get('id');
    this.movieItem=this.movieItems.find(e=>e.id==mid);
    console.log(this.movieItem);
  }
  updateMovieItem(newmovieItem:IMovieItem,date1:Date):void{
    
    newmovieItem.date_of_launch=date1;
    const index: number = this.movieItems.indexOf(this.movieItem);
    if (index !== -1) {
      // {{debugger}}
     
        this.movieItems.splice(index, 1,newmovieItem);
        
    }
    this.flag=true;
    console.log(newmovieItem);
  }
  private updateDate(event)
  {
    console.log(event);
    //this.movieItem.date_of_launch=new Date(event);

    console.log(this.movieItem.date_of_launch);
  }
  logOut():void
  {
    this._authService.logOut();
    this.router.navigate(['/']);
  }


}
