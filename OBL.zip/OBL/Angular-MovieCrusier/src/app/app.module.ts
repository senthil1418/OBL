import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieFavoritesComponent } from 'src/favorites/movie-favorites/movie-favorites.component';
import { MovieListComponent } from '../movies/film/movie-list/movie-list.component';
import { MovieListAdminComponent } from '../movies/film/movie-list-admin/movie-list-admin.component';
import { MovieListCustomerComponent } from '../movies/film/movie-list-customer/movie-list-customer.component';
import { ItemEditComponent } from '../movies/item-edit/item-edit.component';
import { ItemInfoComponent } from '../movies/item-info/item-info.component';
import { SearchComponent } from 'src/movies/search/search.component';
import { LoginComponent } from './site/login/login.component';
import { SignUpComponent } from './site/sign-up/sign-up.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    MovieFavoritesComponent,
    MovieListComponent,
    MovieListAdminComponent,
    MovieListCustomerComponent,
    SearchComponent,
    ItemEditComponent,
    ItemInfoComponent,
    LoginComponent,
    SignUpComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
