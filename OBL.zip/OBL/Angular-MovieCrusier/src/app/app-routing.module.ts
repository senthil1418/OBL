import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { MovieListComponent } from 'src/movies/film/movie-list/movie-list.component';
import { SignUpComponent } from './site/sign-up/sign-up.component';
import { MovieListAdminComponent } from 'src/movies/film/movie-list-admin/movie-list-admin.component';
import { MovieListCustomerComponent } from 'src/movies/film/movie-list-customer/movie-list-customer.component';
import { AuthGuardService } from './auth-guard.service';
import { ItemEditComponent } from 'src/movies/item-edit/item-edit.component';
import { MovieFavoritesComponent } from 'src/favorites/movie-favorites/movie-favorites.component';


const routes: Routes = [
  {
    path:'Login',
    component:LoginComponent
  },
  {
    path:'movieitem',
    component:MovieListComponent
  },
  {
    path:'SignUp',
    component:SignUpComponent
  },
  {
    path:'Admin',
    component:MovieListAdminComponent,
    canActivate:[AuthGuardService]
  },
  {
    path:'Customer',
    component:MovieListCustomerComponent,
    canActivate:[AuthGuardService]
  },
  {
    path:'EditMovie/:id',
    component:ItemEditComponent
  },
  {
    path:'Favorites',
    component:MovieFavoritesComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
