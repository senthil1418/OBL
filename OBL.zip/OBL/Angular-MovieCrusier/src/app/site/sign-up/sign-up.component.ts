import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { IUser } from '../IUser.module';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  msg:string;
  reactiveForm: FormGroup;
  constructor(private _router:Router,private userSevice:UserService) { }
user:IUser={id:null,username:null,firstname:null,lastname:null,password:null};
  ngOnInit() {
    this.initForm();
  }
  private initForm() {
    this.reactiveForm = new FormGroup({
      'userName': new FormControl(),    
      'firstName':new FormControl(),
      'lastName':new FormControl(),
      'pass':new FormControl(),
      'confPass':new FormControl()
    }
    );    
  }

  onSubmit():void{
    if(this.reactiveForm.value.pass==null)
    {
      this.msg="Enter Details";
    }
    else if(this.reactiveForm.value.pass==this.reactiveForm.value.confPass  )
    {
    console.log(this.reactiveForm.value);
    this.user.id=3;
    this.user.username=this.reactiveForm.value.userName;
    this.user.firstname=this.reactiveForm.value.firstName;
    this.user.lastname=this.reactiveForm.value.lastName;
    this.user.password=this.reactiveForm.value.pass;
    this.userSevice.addUser(this.user);
    console.log(this.userSevice.users);
    this._router.navigate(['Login']);
    }
    else
    {
      this.msg="Passwords Do Not Match";
      console.log("No");
    }
  }


}
