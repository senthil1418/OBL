import { Injectable } from '@angular/core';
import { IUser } from './IUser.module';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor() { }
  users:IUser[]=[
    {id:1,username:"Admin",password:"p"},
    {id:2,username:"John",password:"s"}]

    addUser(user:IUser):void
    {
      this.users.push(user);
    }
    getUser(name:string):IUser
    {
      return this.users.find(u=>u.username==name);
    }
}
