export interface IUser
{
    id:number;
    username:string;
    password:string;
    firstname?:string;
    lastname?:string;
}